package com.example.test;

import java.io.IOException;
import java.lang.reflect.Method;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnBufferingUpdateListener;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.media.MediaPlayer.OnVideoSizeChangedListener;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity{
	
    private SurfaceHolder holder;
    LinearLayout ll;
    android.view.ViewGroup.LayoutParams lp2;
    private SimpleMediaPreview mp1;
    private SimpleMediaPreview mp2;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		//setContentView(new MediaPreview(this));
		setContentView(R.layout.activity_main);
		
		ll = (LinearLayout)findViewById(R.id.layout);
		android.view.ViewGroup.LayoutParams lp1 = new LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT,200);
		lp2 = new LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT,android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
		mp1 = new SimpleMediaPreview(this.getApplicationContext());
		mp2 = new SimpleMediaPreview(this.getApplicationContext());
		
		mp1.setPath("http://d1w6nuf8ermkx6.cloudfront.net/output/test-seg.m3u8");	//	モテ子動画
		mp2.setPath("http://d1w6nuf8ermkx6.cloudfront.net/moov/frozen.mp4");	//	fast startのMP4
		
		mp1.setVisibility(View.VISIBLE);
		mp2.setVisibility(View.VISIBLE);
		
		ll.addView(mp1,lp1);
		ll.addView(mp2,lp1);
		
		
		
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode != KeyEvent.KEYCODE_BACK){
			return super.onKeyDown(keyCode, event);
		}else{
			this.finishActivity(1);
			return false;
		}
	}

}
